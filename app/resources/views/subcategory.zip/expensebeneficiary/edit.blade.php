<div class="modal-dialog" role="document">
  <div class="modal-content">

    {!! Form::open(['url' => action('ExpenseBeneficiaryController@update', [$expensebeneficiary->id]), 'method' => 'PUT', 'id' => 'expense_beneficiary_add_form' ]) !!}

    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title">@lang( 'Expense beneficiary' )</h4>
    </div>

    <div class="modal-body">
     <div class="form-group">
        {!! Form::label('name', __( 'Expense beneficiary name' ) . ':*') !!}
          {!! Form::text('name', $expensebeneficiary->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'expense.category_name' )]); !!}
      </div>

      <div class="form-group">
        {!! Form::label('code', __( 'Expense beneficiary email' ) . ':') !!}
          {!! Form::text('email', $expensebeneficiary->email, ['class' => 'form-control', 'placeholder' => __( 'expense.category_code' )]); !!}
      </div>

      <div class="form-group">
        {!! Form::label('code', __( 'Expense beneficiary phone number' ) . ':') !!}
          {!! Form::text('phone_number', $expensebeneficiary->phone_number, ['class' => 'form-control', 'placeholder' => __( 'expense.category_code' )]); !!}
      </div>
      <div class="modal-footer">
      <button type="submit" class="btn btn-primary">@lang( 'messages.update' )</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
    </div>

    {!! Form::close() !!}

  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->