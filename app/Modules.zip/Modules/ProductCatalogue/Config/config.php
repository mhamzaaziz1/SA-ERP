<?php

return [
    'name' => 'ProductCatalogue',
    'module_version' => "0.6",
    'pid' => 8
];
